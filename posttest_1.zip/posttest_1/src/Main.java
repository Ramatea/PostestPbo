import java.util.*;
public class Main {
    static void sleep(int sec){
        try {
            Thread.currentThread().sleep(sec * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws Exception {
        ArrayList<Akun> akun = new ArrayList<>();
        while(true){
            Scanner input = new Scanner(System.in);
            System.out.println("1. Nambah akun");
            System.out.println("2. Tampil akun");
            System.out.println("3. Update akun");
            System.out.println("4. hapus  akun");
            System.out.println("5. keluar");
            System.out.print("Masukkan pilihan >> ");
            int pilihan = input.nextInt();
            switch(pilihan){
                case 1:
                    System.out.println("Tambah data");
                    System.out.print("Masukkan nama akun >> ");
                    String nama_akun = input.next();
                    System.out.print("Masukkan password  >> ");
                    String pass = input.next();
                    Akun akun_baru = new Akun(nama_akun, pass);
                    akun.add(akun_baru);
                    sleep(1);
                    break;
                case 2:
                    System.out.println("Lihat data");
                    for(int i =0; i < akun.size(); i++){
                        akun.get(i).tampak();
                    }
                    System.out.println("");
                    sleep(1);
                    break;
                case 3:
                    System.out.println("Update Data");
                    System.out.print("Masukkan nama akun >> ");
                    String cari_kn = input.next();
                    for(Akun akn : akun){
                        if(akn.user_name.equals(cari_kn)){
                            System.out.print("Masukkan user name baru >> ");
                            akn.setName(input.next());
                            System.out.print("masukkan password baru >> ");
                            akn.setPass(input.next());
                            break;
                        }
                        else{
                            System.out.println("data salah");
                            sleep(1);
                        }
                    }
                    sleep(1);
                    break; 
                case 4:
                    System.out.println("hapus data");
                    System.out.print("Masukkan nama daging >>> ");
                    String us_nm = input.next();
                    for(int i = 0; i < akun.size();  i++){
                        if(akun.get(i).user_name.equals(us_nm)){
                            akun.remove(i);
                        }
                    }
                    sleep(1);
                    break;
                case 5:
                    System.exit(0);
                    break;
                default:
                    System.out.println("=================");
                    System.out.println("pilihan tidak ada");
                    System.out.println("=================");
                    break;
            }
        }
        
    }
}
